import 'package:flutter/material.dart';
import '../models/dashboard_models.dart';

class DashboardProvider with ChangeNotifier {
  final List<Job> _latestJobs = [];

  final List<JobApplication> _fullApplications = [];
  final List<Application> _recentApplications = [];

  final List<AppNotification> _notifications = [];

  List<Job> get latestJobs => _latestJobs;
  List<Application> get recentApplications => _recentApplications;
  List<AppNotification> get notifications => _notifications;

  int get totalApplications => _recentApplications.length;
  int get activeJobs => _latestJobs.length;
  int get applicationsInProgress => _recentApplications
      .where((a) => a.status != 'Rejected' && a.status != 'Hired')
      .length;

  void submitJobApplication(JobApplication app) {
    _fullApplications.insert(0, app);
    _recentApplications.insert(
      0,
      Application(
        jobTitle: app.jobTitle,
        status: app.status,
        dateApplied: app.dateSubmitted,
      ),
    );

    _notifications.insert(
      0,
      AppNotification(
        title: 'New application submitted: ${app.jobTitle}',
        subtitle: 'Just now',
        timestamp: DateTime.now(),
        type: 'application',
      ),
    );

    notifyListeners();
  }

  void deleteApplication(int index) {
    if (index >= 0 && index < _recentApplications.length) {
      final app = _recentApplications[index];
      _recentApplications.removeAt(index);

      _fullApplications.removeWhere(
        (a) => a.jobTitle == app.jobTitle && a.dateSubmitted == app.dateApplied,
      );

      _notifications.insert(
        0,
        AppNotification(
          title: 'Application deleted: ${app.jobTitle}',
          subtitle: 'Just now',
          timestamp: DateTime.now(),
          type: 'status',
        ),
      );

      notifyListeners();
    }
  }
}
