import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/dashboard_provider.dart';

class StatCards extends StatelessWidget {
  const StatCards({super.key});

  @override
  Widget build(BuildContext context) {
    final provider = Provider.of<DashboardProvider>(context);
    final screenWidth = MediaQuery.of(context).size.width;
    final isCompact = screenWidth < 600;

    if (isCompact) {
      return Column(
        children: [
          _StatCard(
            title: 'Active Job Postings',
            value: provider.activeJobs.toString(),
            percentage: '0%',
            isPositive: true,
            icon: Icons.business_center_outlined,
            iconColor: const Color(0xFF5A32A3),
            bgColor: const Color(0xFFF3E8FF),
          ),
          const SizedBox(height: 16),
          _StatCard(
            title: 'Total Applications',
            value: provider.totalApplications.toString(),
            percentage: '0%',
            isPositive: true,
            icon: Icons.description_outlined,
            iconColor: const Color(0xFF3B82F6),
            bgColor: const Color(0xFFEFF6FF),
          ),
          const SizedBox(height: 16),
          _StatCard(
            title: 'Applications in Progress',
            value: provider.applicationsInProgress.toString(),
            percentage: '0%',
            isPositive: true,
            icon: Icons.assignment_outlined,
            iconColor: const Color(0xFF10B981),
            bgColor: const Color(0xFFECFDF5),
          ),
        ],
      );
    }

    return Row(
      children: [
        Expanded(
          child: _StatCard(
            title: 'Active Job Postings',
            value: provider.activeJobs.toString(),
            percentage: '0%',
            isPositive: true,
            icon: Icons.business_center_outlined,
            iconColor: const Color(0xFF5A32A3),
            bgColor: const Color(0xFFF3E8FF),
          ),
        ),
        const SizedBox(width: 24),
        Expanded(
          child: _StatCard(
            title: 'Total Applications',
            value: provider.totalApplications.toString(),
            percentage: '0%',
            isPositive: true,
            icon: Icons.description_outlined,
            iconColor: const Color(0xFF3B82F6),
            bgColor: const Color(0xFFEFF6FF),
          ),
        ),
        const SizedBox(width: 24),
        Expanded(
          child: _StatCard(
            title: 'Applications in Progress',
            value: provider.applicationsInProgress.toString(),
            percentage: '0%',
            isPositive: true,
            icon: Icons.assignment_outlined,
            iconColor: const Color(0xFF10B981),
            bgColor: const Color(0xFFECFDF5),
          ),
        ),
      ],
    );
  }
}

class _StatCard extends StatelessWidget {
  final String title;
  final String value;
  final String percentage;
  final bool isPositive;
  final IconData icon;
  final Color iconColor;
  final Color bgColor;

  const _StatCard({
    required this.title,
    required this.value,
    required this.percentage,
    required this.isPositive,
    required this.icon,
    required this.iconColor,
    required this.bgColor,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.grey[100]!),
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: bgColor,
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(icon, color: iconColor),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(fontSize: 14, color: Colors.grey[600]),
                ),
                const SizedBox(height: 4),
                Wrap(
                  crossAxisAlignment: WrapCrossAlignment.center,
                  spacing: 8,
                  runSpacing: 4,
                  children: [
                    Text(
                      value,
                      style: const TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    if (double.tryParse(percentage.replaceAll('%', '')) !=
                        0) ...[
                      Icon(
                        isPositive ? Icons.arrow_upward : Icons.arrow_downward,
                        size: 14,
                        color: isPositive ? Colors.green : Colors.red,
                      ),
                      Text(
                        percentage,
                        style: TextStyle(
                          fontSize: 12,
                          color: isPositive ? Colors.green : Colors.red,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      Text(
                        'From last month',
                        style: TextStyle(fontSize: 11, color: Colors.grey[400]),
                      ),
                    ] else
                      Text(
                        'No data yet',
                        style: TextStyle(fontSize: 11, color: Colors.grey[400]),
                      ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
