import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';

class ChartSection extends StatelessWidget {
  const ChartSection({super.key});

  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;
    final isCompact = screenWidth < 600;

    if (isCompact) {
      return Column(
        children: [
          _ChartCard(
            title: 'Job Postings Over Time',
            chart: _LineChartWidget(color: const Color(0xFF5A32A3)),
          ),
          const SizedBox(height: 24),
          _ChartCard(
            title: 'Applications Over Time',
            chart: _LineChartWidget(color: const Color(0xFF3B82F6)),
          ),
        ],
      );
    }
    return Row(
      children: [
        Expanded(
          child: _ChartCard(
            title: 'Job Postings Over Time',
            chart: _LineChartWidget(color: const Color(0xFF5A32A3)),
          ),
        ),
        const SizedBox(width: 24),
        Expanded(
          child: _ChartCard(
            title: 'Applications Over Time',
            chart: _LineChartWidget(color: const Color(0xFF3B82F6)),
          ),
        ),
      ],
    );
  }
}

class _ChartCard extends StatelessWidget {
  final String title;
  final Widget chart;

  const _ChartCard({required this.title, required this.chart});

  void _showFeedback(BuildContext context, String action) {
    ScaffoldMessenger.of(context).hideCurrentSnackBar();
    ScaffoldMessenger.of(
      context,
    ).showSnackBar(SnackBar(content: Text('Action: $action')));
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.grey[100]!),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                title,
                style: const TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
              ),
              InkWell(
                onTap: () =>
                    _showFeedback(context, 'Change chart period for $title'),
                borderRadius: BorderRadius.circular(8),
                child: Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 12,
                    vertical: 4,
                  ),
                  decoration: BoxDecoration(
                    border: Border.all(color: Colors.grey[200]!),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: const Row(
                    children: [
                      Text('This Month', style: TextStyle(fontSize: 12)),
                      Icon(Icons.keyboard_arrow_down, size: 16),
                    ],
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 24),
          SizedBox(height: 200, child: chart),
        ],
      ),
    );
  }
}

class _LineChartWidget extends StatelessWidget {
  final Color color;

  const _LineChartWidget({required this.color});

  @override
  Widget build(BuildContext context) {
    return LineChart(
      LineChartData(
        gridData: const FlGridData(show: true, drawVerticalLine: false),
        titlesData: const FlTitlesData(
          show: true,
          rightTitles: AxisTitles(
            sideTitles: SideTitles(showTitles: false),
          ),
          topTitles: AxisTitles(
            sideTitles: SideTitles(showTitles: false),
          ),
          bottomTitles: AxisTitles(
            sideTitles: SideTitles(showTitles: false),
          ),
        ),
        borderData: FlBorderData(show: false),
        lineBarsData: [
          LineChartBarData(
            spots: const [
              FlSpot(0, 0),
              FlSpot(1, 0),
              FlSpot(2, 0),
              FlSpot(3, 0),
              FlSpot(4, 0),
              FlSpot(5, 0),
              FlSpot(6, 0),
              FlSpot(7, 0),
              FlSpot(8, 0),
              FlSpot(9, 0),
              FlSpot(10, 0),
              FlSpot(11, 0),
              FlSpot(12, 0),
            ],
            isCurved: true,
            color: color,
            barWidth: 3,
            isStrokeCapRound: true,
            dotData: const FlDotData(show: true),
            belowBarData: BarAreaData(
              show: true,
              color: color.withValues(alpha: 0.1),
            ),
          ),
        ],
      ),
    );
  }
}
