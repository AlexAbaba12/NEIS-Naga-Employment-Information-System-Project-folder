import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';
import '../providers/dashboard_provider.dart';
import '../screens/job_application_screen.dart';
import '../models/dashboard_models.dart';

class TablesSection extends StatelessWidget {
  const TablesSection({super.key});

  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;
    final isCompact = screenWidth < 1100;

    if (isCompact) {
      return Column(
        children: [
          _TableCard(
            title: 'Latest Job Postings',
            actionText: 'View all',
            child: const _LatestJobsTable(),
          ),
          const SizedBox(height: 24),
          _TableCard(
            title: 'Recent Applications',
            actionText: 'View all',
            child: const _RecentApplicationsTable(),
          ),
        ],
      );
    }
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Expanded(
          child: _TableCard(
            title: 'Latest Job Postings',
            actionText: 'View all',
            child: const _LatestJobsTable(),
          ),
        ),
        const SizedBox(width: 24),
        Expanded(
          child: _TableCard(
            title: 'Recent Applications',
            actionText: 'View all',
            child: const _RecentApplicationsTable(),
          ),
        ),
      ],
    );
  }
}

class _TableCard extends StatelessWidget {
  final String title;
  final String actionText;
  final Widget child;

  const _TableCard({
    required this.title,
    required this.actionText,
    required this.child,
  });
  void _showFeedback(BuildContext context, String action) {
    ScaffoldMessenger.of(context).hideCurrentSnackBar();
    ScaffoldMessenger.of(
      context,
    ).showSnackBar(SnackBar(content: Text('Action: $action')));
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.grey[100]!),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                title,
                style: const TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
              ),
              TextButton(
                onPressed: () =>
                    _showFeedback(context, 'View all ${title.toLowerCase()}'),
                child: Text(
                  actionText,
                  style: const TextStyle(
                    color: Color(0xFF5A32A3),
                    fontSize: 12,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          child,
          if (title == 'Latest Job Postings') ...[
            const SizedBox(height: 16),
            Center(
              child: TextButton.icon(
                onPressed: () =>
                    _showFeedback(context, 'View all job postings'),
                icon: const Text('View all job postings'),
                label: const Icon(Icons.arrow_forward, size: 16),
                style: TextButton.styleFrom(
                  foregroundColor: const Color(0xFF5A32A3),
                ),
              ),
            ),
          ] else ...[
            const SizedBox(height: 16),
            Center(
              child: TextButton.icon(
                onPressed: () =>
                    _showFeedback(context, 'View all applications'),
                icon: const Text('View all applications'),
                label: const Icon(Icons.arrow_forward, size: 16),
                style: TextButton.styleFrom(
                  foregroundColor: const Color(0xFF5A32A3),
                ),
              ),
            ),
          ],
        ],
      ),
    );
  }
}

class _LatestJobsTable extends StatelessWidget {
  const _LatestJobsTable();

  @override
  Widget build(BuildContext context) {
    final jobs = Provider.of<DashboardProvider>(context).latestJobs;

    if (jobs.isEmpty) {
      return const SizedBox(
        width: double.infinity,
        height: 150,
        child: Center(
          child: Text(
            'No active job postings available',
            style: TextStyle(color: Colors.grey, fontSize: 14),
          ),
        ),
      );
    }
    return LayoutBuilder(
      builder: (context, constraints) {
        return SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: ConstrainedBox(
            constraints: BoxConstraints(
              minWidth: constraints.maxWidth > 700 ? constraints.maxWidth : 700,
            ),
            child: Table(
              columnWidths: const {
                0: FlexColumnWidth(),
                1: FixedColumnWidth(150),
                2: FixedColumnWidth(100),
                3: FixedColumnWidth(120),
              },
              defaultVerticalAlignment: TableCellVerticalAlignment.middle,
              children: [
                TableRow(
                  children: [
                    _headerCell('Job Title'),
                    _headerCell('Category'),
                    _headerCell('Location'),
                    _headerCell('Posted Date'),
                  ],
                ),
                ...jobs.map((job) => TableRow(
                      children: [
                        _dataCell(
                          Row(
                            children: [
                              Container(
                                padding: const EdgeInsets.all(6),
                                decoration: BoxDecoration(
                                  color: const Color(0xFFF3E8FF),
                                  borderRadius: BorderRadius.circular(8),
                                ),
                                child: const Icon(Icons.business_center_outlined,
                                    size: 14, color: Color(0xFF5A32A3)),
                              ),
                              const SizedBox(width: 8),
                              Expanded(
                                child: Text(
                                  job.title,
                                  style: const TextStyle(
                                      fontWeight: FontWeight.w600,
                                      fontSize: 12),
                                  overflow: TextOverflow.ellipsis,
                                ),
                              ),
                            ],
                          ),
                        ),
                        _dataCell(Text(job.category,
                            style: const TextStyle(
                                color: Colors.grey, fontSize: 12))),
                        _dataCell(Text(job.location,
                            style: const TextStyle(
                                color: Colors.grey, fontSize: 12))),
                        _dataCell(Text(
                            DateFormat('MMM dd, yyyy').format(job.postedDate),
                            style: const TextStyle(
                                color: Colors.grey, fontSize: 12))),
                      ],
                    )),
              ],
            ),
          ),
        );
      },
    );
  }
  Widget _headerCell(String text) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 12),
      child: Text(
        text,
        style: TextStyle(
          fontSize:12,
          color: Colors.grey[400],
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }
  Widget _dataCell(Widget child) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 12),
      child: child,
    );
  }
}

class _RecentApplicationsTable extends StatelessWidget {
  const _RecentApplicationsTable();

  @override
  Widget build(BuildContext context) {
    final applications =
        Provider.of<DashboardProvider>(context).recentApplications;

    if (applications.isEmpty) {
      return const SizedBox(
        width: double.infinity,
        height: 150,
        child: Center(
          child: Text(
            'No recent applications',
            style: TextStyle(color: Colors.grey, fontSize: 14),
          ),
        ),
      );
    }
    return LayoutBuilder(
      builder: (context, constraints) {
        return SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: ConstrainedBox(
            constraints: BoxConstraints(
              minWidth: constraints.maxWidth > 700 ? constraints.maxWidth : 700,
            ),
            child: Table(
              columnWidths: const {
                0: FlexColumnWidth(2),
                1: FlexColumnWidth(1),
                2: FlexColumnWidth(1),
              },
              children: [
                TableRow(
                  children: [
                    _headerCell('Job Title'),
                    _headerCell('Status'),
                    _headerCell('Date Applied'),
                  ],
                ),
                ...applications.map((app) => TableRow(
                      children: [
                        _dataCell(Text(app.jobTitle,
                            style: const TextStyle(
                                fontWeight: FontWeight.w600, fontSize: 12))),
                        _dataCell(_StatusBadge(status: app.status)),
                        _dataCell(Text(
                            DateFormat('MMM dd, yyyy').format(app.dateApplied),
                            style: const TextStyle(
                                color: Colors.grey, fontSize: 12))),
                      ],
                    )),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _headerCell(String text) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 12),
      child: Text(
        text,
        style: TextStyle(
          fontSize: 12,
          color: Colors.grey[400],
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }
  Widget _dataCell(Widget child) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 12),
      child: child,
    );
  }
}

class _StatusBadge extends StatelessWidget {
  final String status;

  const _StatusBadge({required this.status});

  @override
  Widget build(BuildContext context) {
    Color color;
    Color bgColor;

    switch (status) {
      case 'Pending':
        color = const Color(0xFF5A32A3);
        bgColor = const Color(0xFFF3E8FF);
        break;
      case 'Under Review':
        color = const Color(0xFF3B82F6);
        bgColor = const Color(0xFFEFF6FF);
        break;
      case 'For Interview':
        color = const Color(0xFFF59E0B);
        bgColor = const Color(0xFFFEF3C7);
        break;
      case 'Hired':
        color = const Color(0xFF10B981);
        bgColor = const Color(0xFFECFDF5);
        break;
      case 'Rejected':
        color = const Color(0xFFEF4444);
        bgColor = const Color(0xFFFEE2E2);
        break;
      case 'Pending Revision':
        color = const Color(0xFF6B7280);
        bgColor = const Color(0xFFF3F4F6);
        break;
      default:
        color = Colors.grey;
        bgColor = Colors.grey[100]!;
    }

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: bgColor,
        borderRadius: BorderRadius.circular(8),
      ),
      child: Text(
        status,
        textAlign: TextAlign.center,
        style: TextStyle(
          color: color,
          fontSize: 10,
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }
}

