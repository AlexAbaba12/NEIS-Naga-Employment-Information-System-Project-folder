import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:provider/provider.dart';
import '../providers/dashboard_provider.dart';

class NotificationsPanel extends StatelessWidget {
  const NotificationsPanel({super.key});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        const _RecentNotifications(),
        const SizedBox(height: 24),
        const _ApplicationStatusSummary(),
      ],
    );
  }
}

class _RecentNotifications extends StatelessWidget {
  const _RecentNotifications();

  void _showFeedback(BuildContext context, String action) {
    ScaffoldMessenger.of(context).hideCurrentSnackBar();
    ScaffoldMessenger.of(
      context,
    ).showSnackBar(SnackBar(content: Text('Action: $action')));
  }

  @override
  Widget build(BuildContext context) {
    final notifications = Provider.of<DashboardProvider>(context).notifications;

    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.grey[100]!),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text(
                'Recent Notifications',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
              ),
              TextButton(
                onPressed: () =>
                    _showFeedback(context, 'View all notifications'),
                child: const Text(
                  'View all',
                  style: TextStyle(color: Color(0xFF5A32A3), fontSize: 12),
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          if (notifications.isEmpty)
            const Padding(
              padding: EdgeInsets.symmetric(vertical: 24.0),
              child: Center(
                child: Text(
                  'No notifications yet',
                  style: TextStyle(color: Colors.grey, fontSize: 12),
                ),
              ),
            )
          else
            ListView.separated(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: notifications.take(4).length,
              separatorBuilder: (context, index) => const SizedBox(height: 16),
              itemBuilder: (context, index) {
                final notification = notifications[index];
                return InkWell(
                  onTap: () => _showFeedback(
                    context,
                    'Notification: ${notification.title}',
                  ),
                  borderRadius: BorderRadius.circular(8),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(vertical: 4),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          padding: const EdgeInsets.all(8),
                          decoration: BoxDecoration(
                            color: _getNotificationBgColor(notification.type),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: Icon(
                            _getNotificationIcon(notification.type),
                            size: 16,
                            color: _getNotificationColor(notification.type),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                notification.title,
                                style: const TextStyle(
                                  fontSize: 12,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                              const SizedBox(height: 4),
                              Text(
                                notification.subtitle,
                                style: TextStyle(
                                  fontSize: 10,
                                  color: Colors.grey[400],
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
        ],
      ),
    );
  }

  IconData _getNotificationIcon(String type) {
    switch (type) {
      case 'job':
        return Icons.business_center_outlined;
      case 'application':
        return Icons.description_outlined;
      case 'interview':
        return Icons.calendar_today_outlined;
      case 'status':
        return Icons.check_circle_outline;
      default:
        return Icons.notifications_none;
    }
  }

  Color _getNotificationColor(String type) {
    switch (type) {
      case 'job':
        return const Color(0xFF5A32A3);
      case 'application':
        return const Color(0xFF3B82F6);
      case 'interview':
        return const Color(0xFFF59E0B);
      case 'status':
        return const Color(0xFF10B981);
      default:
        return Colors.grey;
    }
  }

  Color _getNotificationBgColor(String type) {
    return _getNotificationColor(type).withValues(alpha: 0.1);
  }
}

class _ApplicationStatusSummary extends StatelessWidget {
  const _ApplicationStatusSummary();

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.grey[100]!),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Application Status Summary',
            style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 24),
          SizedBox(
            height: 200,
            child: PieChart(
              PieChartData(
                sectionsSpace: 0,
                centerSpaceRadius: 60,
                sections: [
                  PieChartSectionData(
                    color: Colors.grey[200]!,
                    value: 1,
                    title: '',
                    radius: 20,
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),
          const _StatusLegendItem(
            label: 'Pending',
            count: 0,
            percentage: 0,
            color: Color(0xFF5A32A3),
          ),
          const _StatusLegendItem(
            label: 'Under Review',
            count: 0,
            percentage: 0,
            color: Color(0xFF3B82F6),
          ),
          const _StatusLegendItem(
            label: 'For Interview',
            count: 0,
            percentage: 0,
            color: Color(0xFFF59E0B),
          ),
          const _StatusLegendItem(
            label: 'Hired',
            count: 0,
            percentage: 0,
            color: Color(0xFF10B981),
          ),
        ],
      ),
    );
  }
}

class _StatusLegendItem extends StatelessWidget {
  final String label;
  final int count;
  final double percentage;
  final Color color;

  const _StatusLegendItem({
    required this.label,
    required this.count,
    required this.percentage,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: [
          Container(
            width: 8,
            height: 8,
            decoration: BoxDecoration(color: color, shape: BoxShape.circle),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              label,
              style: const TextStyle(fontSize: 12, color: Colors.grey),
            ),
          ),
          Text(
            '$count ($percentage%)',
            style: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold),
          ),
        ],
      ),
    );
  }
}
