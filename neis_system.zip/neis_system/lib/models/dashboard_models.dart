class Job {
  final String id;
  final String title;
  final String category;
  final String location;
  final DateTime postedDate;

  Job({
    required this.id,
    required this.title,
    required this.category,
    required this.location,
    required this.postedDate,
  });
}

class JobApplication {
  final String applicationId; // System generated
  final String jobId;
  final String jobTitle;

  // Personal Information
  final String firstName;
  final String lastName;
  final String? middleName;
  final String gender;
  final String civilStatus;

  // Contact Information
  final String email;
  final String contactNumber;

  // Educational Background
  final String highestEducation;
  final String schoolName;
  final String course;

  // Work Experience
  final String companyName;
  final String position;
  final int yearsOfExperience;

  // Skills
  final List<String> skills;

  // File (Mocked as string path)
  final String resumePath;

  final String status;
  final DateTime dateSubmitted;

  JobApplication({
    required this.applicationId,
    required this.jobId,
    required this.jobTitle,
    required this.firstName,
    required this.lastName,
    this.middleName,
    required this.gender,
    required this.civilStatus,
    required this.email,
    required this.contactNumber,
    required this.highestEducation,
    required this.schoolName,
    required this.course,
    required this.companyName,
    required this.position,
    required this.yearsOfExperience,
    required this.skills,
    required this.resumePath,
    this.status = 'Pending',
    required this.dateSubmitted,
  });
}

class Application {
  final String jobTitle;
  final String status;
  final DateTime dateApplied;

  Application({
    required this.jobTitle,
    required this.status,
    required this.dateApplied,
  });
}

class AppNotification {
  final String title;
  final String subtitle;
  final DateTime timestamp;
  final String type; // 'job', 'application', 'interview', 'status'

  AppNotification({
    required this.title,
    required this.subtitle,
    required this.timestamp,
    required this.type,
  });
}
