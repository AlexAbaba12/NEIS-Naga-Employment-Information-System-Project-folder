import 'package:flutter/material.dart';
import '../widgets/sidebar.dart';
import '../widgets/dashboard_header.dart';
import '../widgets/stat_cards.dart';
import '../widgets/chart_section.dart';

import '../widgets/tables_section.dart';
import '../widgets/notifications_panel.dart';

class DashboardScreen extends StatelessWidget {
  const DashboardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;
    final isMobile = screenWidth < 600;
    final isTablet = screenWidth < 1100;

    return Scaffold(

      body: Row(
        children: [
          if (!isMobile) const Sidebar(isDashboard: true),
          Expanded(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(24.0),
              child: Center(
                child: ConstrainedBox(
                  constraints: const BoxConstraints(maxWidth: 1400),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const DashboardHeader(),

                      const SizedBox(height: 24),
                      const StatCards(),
                      const SizedBox(height: 24),
                      if (isTablet)
                        Column(
                          children: [
                          const ChartSection(),
                          const SizedBox(height: 24),
                          const TablesSection(),
                          const SizedBox(height: 24),
                          const NotificationsPanel(),
                        ],
                        )
                      else 
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.start,

                          children: [
                            Expanded(
                              flex: 2,
                              child: Column(
                                children: [
                                  const ChartSection(),
                                  const SizedBox(height: 24),
                                  const TablesSection(),
                                ],
                              ),
                            ),
                            const SizedBox(width: 24),
                            Expanded(
                              flex: 1,
                              child: const NotificationsPanel(),
                            ),
                          ],
                      ),
                      const SizedBox(height: 48),
                      const Center(
                        child: Text(
                          '© 2026 NEIS Naga Employment Information System. All rights reserved.',
                          style: TextStyle(color: Colors.grey, fontSize: 12),
                        ),
                      ),
                        
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ), 
      drawer: isMobile
          ? const Drawer(child: Sidebar(isDashboard: true)) : null,
    );
  }
}
