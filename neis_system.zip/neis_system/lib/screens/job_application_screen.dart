import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/dashboard_models.dart';
import '../providers/dashboard_provider.dart';

class JobApplicationScreen extends StatefulWidget {
  final Job job;

  const JobApplicationScreen({super.key, required this.job});

  @override
  State<JobApplicationScreen> createState() => _JobApplicationScreenState();
}

class _JobApplicationScreenState extends State<JobApplicationScreen> {
  final _formKey = GlobalKey<FormState>();

  // Controllers
  final _firstNameController = TextEditingController();
  final _lastNameController = TextEditingController();
  final _middleNameController = TextEditingController();
  final _emailController = TextEditingController();
  final _contactNumberController = TextEditingController();
  final _schoolNameController = TextEditingController();
  final _courseController = TextEditingController();
  final _companyNameController = TextEditingController();
  final _positionController = TextEditingController();
  final _yearsController = TextEditingController();
  final _skillsController = TextEditingController();

  String _gender = 'Male';
  String _civilStatus = 'Single';
  String _highestEducation = 'High School';

  final String _applicationId =
      'APP-${DateTime.now().millisecondsSinceEpoch.toString().substring(7)}';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF8F9FD),
      appBar: AppBar(
        title: const Text('Job Application Form'),
        backgroundColor: Colors.white,
        foregroundColor: const Color(0xFF1F2937),
        elevation: 0,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(32),
        child: Container(
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(16),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withValues(alpha: 0.05),
                blurRadius: 10,
                offset: const Offset(0, 4),
              ),
            ],
          ),
          child: Form(
            key: _formKey,
            child: Padding(
              padding: const EdgeInsets.all(24),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _buildSectionHeader(
                    '1. Application Info',
                    Icons.info_outline,
                  ),
                  _buildReadOnlyField('Application ID', _applicationId),
                  Row(
                    children: [
                      Expanded(
                        child: _buildReadOnlyField('Job ID', widget.job.id),
                      ),
                      const SizedBox(width: 16),
                      Expanded(
                        child: _buildReadOnlyField(
                          'Job Title',
                          widget.job.title,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),

                  _buildSectionHeader(
                    '2. Personal Information',
                    Icons.person_outline,
                  ),
                  Row(
                    children: [
                      Expanded(
                        child: _buildTextField(
                          'First Name',
                          _firstNameController,
                        ),
                      ),
                      const SizedBox(width: 16),
                      Expanded(
                        child: _buildTextField(
                          'Last Name',
                          _lastNameController,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  _buildTextField(
                    'Middle Name',
                    _middleNameController,
                    required: false,
                  ),
                  const SizedBox(height: 16),
                  Row(
                    children: [
                      Expanded(
                        child: _buildDropdownField(
                          'Gender',
                          ['Male', 'Female', 'Prefer not to Specify'],
                          _gender,
                          (val) => setState(() => _gender = val!),
                        ),
                      ),
                      const SizedBox(width: 16),
                      Expanded(
                        child: _buildDropdownField(
                          'Civil Status',
                          ['Single', 'Married', 'Widowed', 'Separated'],
                          _civilStatus,
                          (val) => setState(() => _civilStatus = val!),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 32),

                  _buildSectionHeader(
                    '3. Contact Information',
                    Icons.contact_page_outlined,
                  ),
                  _buildTextField(
                    'Email Address',
                    _emailController,
                    icon: Icons.email_outlined,
                  ),
                  const SizedBox(height: 16),
                  _buildTextField(
                    'Contact Number (11-13 digits)',
                    _contactNumberController,
                    icon: Icons.phone_outlined,
                    keyboardType: TextInputType.phone,
                    validator: (val) {
                      if (val == null || val.isEmpty) return 'Required';
                      if (!RegExp(r'^\d{11,13}$').hasMatch(val)) {
                        return 'Must be 11-13 digits';
                      }
                      return null;
                    },
                  ),
                  const SizedBox(height: 32),

                  _buildSectionHeader(
                    '4. Educational Background',
                    Icons.school_outlined,
                  ),
                  _buildDropdownField(
                    'Highest Education',
                    [
                      'High School',
                      'Vocational',
                      'College Graduate',
                      'Post Graduate',
                    ],
                    _highestEducation,
                    (val) => setState(() => _highestEducation = val!),
                  ),
                  const SizedBox(height: 16),
                  _buildTextField('School Name', _schoolNameController),
                  const SizedBox(height: 16),
                  _buildTextField('Course', _courseController),
                  const SizedBox(height: 32),

                  _buildSectionHeader('5. Work Experience', Icons.work_outline),
                  _buildTextField('Company Name', _companyNameController),
                  const SizedBox(height: 16),
                  _buildTextField('Position', _positionController),
                  const SizedBox(height: 16),
                  _buildTextField(
                    'Years of Experience (0-50)',
                    _yearsController,
                    keyboardType: TextInputType.number,
                    validator: (val) {
                      if (val == null || val.isEmpty) return 'Required';
                      final years = int.tryParse(val);
                      if (years == null || years < 0 || years > 50) {
                        return 'Must be between 0 and 50';
                      }
                      return null;
                    },
                  ),
                  const SizedBox(height: 32),

                  _buildSectionHeader('6. Skills', Icons.bolt_outlined),
                  _buildTextField(
                    'Skills (comma separated)',
                    _skillsController,
                    hint: 'e.g. Flutter, Dart, SQL',
                  ),
                  const SizedBox(height: 32),

                  _buildSectionHeader('7. Resume', Icons.upload_file_outlined),
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(24),
                    decoration: BoxDecoration(
                      border: Border.all(
                        color: Colors.grey[300]!,
                        style: BorderStyle.solid,
                      ),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Column(
                      children: [
                        const Icon(
                          Icons.cloud_upload_outlined,
                          size: 48,
                          color: Colors.grey,
                        ),
                        const SizedBox(height: 8),
                        const Text(
                          'Upload Resume (PDF, DOCX)',
                          style: TextStyle(color: Colors.grey),
                        ),
                        const SizedBox(height: 16),
                        ElevatedButton(
                          onPressed: () {},
                          style: ElevatedButton.styleFrom(
                            backgroundColor: const Color(0xFF5A32A3),
                            foregroundColor: Colors.white,
                          ),
                          child: const Text('Browse Files'),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 48),

                  SizedBox(
                    width: double.infinity,
                    height: 56,
                    child: ElevatedButton(
                      onPressed: _submitForm,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFF5A32A3),
                        foregroundColor: Colors.white,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                      child: const Text(
                        'Submit Application',
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildSectionHeader(String title, IconData icon) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 24),
      child: Row(
        children: [
          Icon(icon, color: const Color(0xFF5A32A3)),
          const SizedBox(width: 12),
          Text(
            title,
            style: const TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
              color: Color(0xFF1F2937),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTextField(
    String label,
    TextEditingController controller, {
    IconData? icon,
    String? hint,
    bool required = true,
    TextInputType? keyboardType,
    String? Function(String?)? validator,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: const TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 14,
            color: Color(0xFF374151),
          ),
        ),
        const SizedBox(height: 8),
        TextFormField(
          controller: controller,
          keyboardType: keyboardType,
          decoration: InputDecoration(
            hintText: hint ?? 'Enter your $label',
            prefixIcon: icon != null ? Icon(icon) : null,
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
            contentPadding: const EdgeInsets.symmetric(
              horizontal: 16,
              vertical: 16,
            ),
          ),
          validator:
              validator ??
              (required
                  ? (val) => val == null || val.isEmpty
                        ? 'This field is required'
                        : null
                  : null),
        ),
      ],
    );
  }

  Widget _buildReadOnlyField(String label, String value) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: const TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 14,
            color: Color(0xFF374151),
          ),
        ),
        const SizedBox(height: 8),
        Container(
          width: double.infinity,
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: Colors.grey[100],
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: Colors.grey[300]!),
          ),
          child: Text(value, style: const TextStyle(color: Colors.black87)),
        ),
        const SizedBox(height: 16),
      ],
    );
  }

  Widget _buildDropdownField(
    String label,
    List<String> options,
    String value,
    Function(String?) onChanged,
  ) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: const TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 14,
            color: Color(0xFF374151),
          ),
        ),
        const SizedBox(height: 8),
        DropdownButtonFormField<String>(
          initialValue: value,
          items: options
              .map((e) => DropdownMenuItem(value: e, child: Text(e)))
              .toList(),
          onChanged: onChanged,
          decoration: InputDecoration(
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
            contentPadding: const EdgeInsets.symmetric(horizontal: 16),
          ),
        ),
      ],
    );
  }

  void _submitForm() {
    if (_formKey.currentState!.validate()) {
      final app = JobApplication(
        applicationId: _applicationId,
        jobId: widget.job.id,
        jobTitle: widget.job.title,
        firstName: _firstNameController.text,
        lastName: _lastNameController.text,
        middleName: _middleNameController.text,
        gender: _gender,
        civilStatus: _civilStatus,
        email: _emailController.text,
        contactNumber: _contactNumberController.text,
        highestEducation: _highestEducation,
        schoolName: _schoolNameController.text,
        course: _courseController.text,
        companyName: _companyNameController.text,
        position: _positionController.text,
        yearsOfExperience: int.tryParse(_yearsController.text) ?? 0,
        skills: _skillsController.text.split(',').map((e) => e.trim()).toList(),
        resumePath: 'mock_resume_path.pdf',
        dateSubmitted: DateTime.now(),
      );

      Provider.of<DashboardProvider>(
        context,
        listen: false,
      ).submitJobApplication(app);

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Application submitted successfully!')),
      );
      Navigator.pop(context);
    }
  }
}
